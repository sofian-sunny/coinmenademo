import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';

import Home from '../screens/Home/iindex';
import Country from '../screens/Home/iindex';

type MainStackParamList = {
  Home: {countryId: string};
  Country: {stats: 'weekly' | 'monthly'} | undefined;
};

const MainStack = createStackNavigator<MainStackParamList>();

export const Main = () => (
  <MainStack.Navigator initialRouteName="Home">
    <MainStack.Screen name="Home" component={Home} />
    <MainStack.Screen
      name="Country"
      component={Country}
      initialParams={{stats: 'weekly'}}
    />
  </MainStack.Navigator>
);

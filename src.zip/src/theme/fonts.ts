import Matrics from './metrics'


const size = {
    font10: Matrics.screenWidth * (10 / 360),
    font12: Matrics.screenWidth * (12 / 360),
    font14: Matrics.screenWidth * (14 / 360),
    font16: Matrics.screenWidth * (16 / 360),
    font18: Matrics.screenWidth * (18 / 360),
    font20: Matrics.screenWidth * (20 / 360),
}

const weight = {
    full: '900',
    semi: '600',
    low: '400',
    bold: 'bold',
    normal: 'normal'
}

export default { size, weight }
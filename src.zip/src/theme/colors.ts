const colors = {
    white: '#ffffff',
    black: '#000000',    
}

export default colors
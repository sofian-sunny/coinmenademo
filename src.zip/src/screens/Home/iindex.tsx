import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import {useCovidStatsStore} from '../../stores/covidStatsData';
import {useQuery} from 'react-query';

interface HomeScreenProps {
  navigation: ReactNavigation.RootParamList;
}

const Home = ({navigation}: HomeScreenProps) => {
  console.log({navigation});
  const players = useCovidStatsStore((state: any) => state);

  const {isLoading, isError, data} = useQuery('summary', () =>
    players.fetchCovidStats('summary'),
  );

  console.log('isLoading, isError, data ', isLoading, isError, data);

  if (isError) {
    return (
      <>
        <Text style={styles.header}>Error</Text>
      </>
    );
  }

  if (isLoading) {
    return <Text style={styles.header}>Fetching</Text>;
  }

  if (data) {
    return (
      <View style={styles.container}>
        <React.Fragment>
          <Text style={styles.header}>all posts</Text>
        </React.Fragment>
      </View>
    );
  }

  return <Text style={styles.header}>No data present</Text>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  wrapper: {
    flex: 1,
    paddingVertical: 30,
  },
  item: {
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  header: {
    textAlign: 'center',
    textTransform: 'capitalize',
    fontWeight: 'bold',
    fontSize: 30,
    color: '#000000',
    paddingVertical: 10,
  },
  post: {
    backgroundColor: '#000000',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  postTitle: {color: '#ffffff', textTransform: 'capitalize'},
});

export default Home;

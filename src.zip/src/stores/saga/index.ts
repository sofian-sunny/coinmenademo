import {all, fork} from 'redux-saga/effects';
import covidStatsSaga from './covidStatsSaga';

export function* rootSaga() {
  yield all([fork(covidStatsSaga)]);
}

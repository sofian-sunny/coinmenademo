import {all, call, put, takeLatest} from 'redux-saga/effects';
import {FetchCovidStatisticsResponse} from '../types';
import {
  fetchCovidStatsSummerySuccessAction,
  FetchCovidStatsFailureAction,
} from '../actions/fetchCovidStatsAction';
import {actionTypes} from '../constants';
import {fetchCovidStatsApi} from '../services';

const getPosts = () => {
  return fetchCovidStatsApi('summary');
};

function* fetchCovidStatsSummery() {
  try {
    const response: FetchCovidStatisticsResponse = yield call(getPosts);

    console.log({response});

    yield put(fetchCovidStatsSummerySuccessAction(response));
  } catch (e) {
    yield put(FetchCovidStatsFailureAction());
  }
}

function* covidStatsSaga() {
  yield all([
    takeLatest(actionTypes.GET_COVID_STATS_DATA, fetchCovidStatsSummery),
  ]);
}

export default covidStatsSaga;

import {http} from './api';
import {FetchCovidStatisticsResponse} from '../types';

export const fetchCovidStatsApi = async (
  requestUrl: string,
): Promise<FetchCovidStatisticsResponse> => {
  const {data} = await http.get<FetchCovidStatisticsResponse>(`/${requestUrl}`);
  return data;
};

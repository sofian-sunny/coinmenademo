import {CovidStatsStateType, CovidStatsReducerActionType} from '../types';
import {actionTypes} from '../constants';

const initialState: CovidStatsStateType = {
  data: null,
  isFetching: false,
  error: false,
};

const covidStatsReducer = (
  state = initialState,
  action: CovidStatsReducerActionType,
) => {
  switch (action.type) {
    case actionTypes.FETCHING_COVID_STATS_DATA:
      return {
        ...state,
        data: action.payload,
        isFetching: true,
      };
    case actionTypes.FETCHING_COVID_STATS_DATA_SUCCESS: {
      return {
        ...state,
        isFetching: false,
        data: action.payload,
      };
    }
    case actionTypes.FETCHING_OVID_STATS_DATA_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true,
        data: null,
      };
    default:
      return state;
  }
};

export default covidStatsReducer;

import {combineReducers} from 'redux';
import covidStatsReducer, {CovidStatsStateType} from './covidStatsReducer';

// interface RootReducerType { }

export interface AppState {
  covidStatsReducer: CovidStatsStateType;
}

const rootReducer = combineReducers({covidStatsReducer});

export type RootState = ReturnType<typeof rootReducer>;
export default rootReducer;

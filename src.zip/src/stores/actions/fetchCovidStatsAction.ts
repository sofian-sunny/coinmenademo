import {
  FetchCovidRequest,
  FetchCovidStatsSuccess,
  FetchCovidStatisticsResponse,
  FetchCovidStatsFailure,
} from '../types';
import {actionTypes} from '../constants';

export const fetchingCovidStatsSummeryAction = (): FetchCovidRequest => ({
  type: actionTypes.GET_COVID_STATS_DATA,
});

export const fetchCovidStatsSummerySuccessAction = (
  payload: FetchCovidStatisticsResponse,
): FetchCovidStatsSuccess => ({
  type: actionTypes.FETCHING_COVID_STATS_DATA_SUCCESS,
  payload,
});

export const FetchCovidStatsFailureAction = (): FetchCovidStatsFailure => ({
  type: actionTypes.FETCHING_OVID_STATS_DATA_FAILURE,
});

import create from 'zustand';
import {fetchCovidStatsApi} from './services';
import {CovidStatsStore, FetchCovidStatisticsResponse} from './types';

export const fetchPosts = async (
  serviceUrl: string,
): Promise<FetchCovidStatisticsResponse> => {
  return await fetchCovidStatsApi(serviceUrl);
};

export const useCovidStatsStore = create<CovidStatsStore>(set => ({
  covidStats: {},
  fetchCovidStats: (serviceUrl: string) => {
    const response = fetchPosts(serviceUrl);
    set({covidStats: response});
    return response;
  },
}));
